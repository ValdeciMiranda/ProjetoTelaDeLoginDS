﻿namespace UI_ProjetoDS
{
    partial class Login
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Login));
            this.lblTitle = new System.Windows.Forms.Label();
            this.btnLogar = new System.Windows.Forms.Button();
            this.txbUsername = new System.Windows.Forms.TextBox();
            this.lklRecovery = new System.Windows.Forms.LinkLabel();
            this.lblUsername = new System.Windows.Forms.Label();
            this.lblPass = new System.Windows.Forms.Label();
            this.txbPass = new System.Windows.Forms.TextBox();
            this.lklRegister = new System.Windows.Forms.LinkLabel();
            this.SuspendLayout();
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.BackColor = System.Drawing.SystemColors.Highlight;
            this.lblTitle.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblTitle.Font = new System.Drawing.Font("Calibri", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.lblTitle.Location = new System.Drawing.Point(238, 9);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(286, 38);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "ENTRE NA SUA CONTA";
            this.lblTitle.Click += new System.EventHandler(this.lblTitle_Click);
            // 
            // btnLogar
            // 
            this.btnLogar.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnLogar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnLogar.FlatAppearance.BorderColor = System.Drawing.Color.LightBlue;
            this.btnLogar.FlatAppearance.BorderSize = 3;
            this.btnLogar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.LightBlue;
            this.btnLogar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DodgerBlue;
            this.btnLogar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLogar.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogar.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btnLogar.Location = new System.Drawing.Point(319, 246);
            this.btnLogar.Name = "btnLogar";
            this.btnLogar.Size = new System.Drawing.Size(122, 54);
            this.btnLogar.TabIndex = 5;
            this.btnLogar.Text = "ENTRAR";
            this.btnLogar.UseVisualStyleBackColor = false;
            // 
            // txbUsername
            // 
            this.txbUsername.Location = new System.Drawing.Point(12, 95);
            this.txbUsername.Name = "txbUsername";
            this.txbUsername.Size = new System.Drawing.Size(730, 20);
            this.txbUsername.TabIndex = 2;
            // 
            // lklRecovery
            // 
            this.lklRecovery.ActiveLinkColor = System.Drawing.Color.Black;
            this.lklRecovery.AutoSize = true;
            this.lklRecovery.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lklRecovery.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.lklRecovery.Location = new System.Drawing.Point(179, 185);
            this.lklRecovery.Name = "lklRecovery";
            this.lklRecovery.Size = new System.Drawing.Size(384, 15);
            this.lklRecovery.TabIndex = 7;
            this.lklRecovery.TabStop = true;
            this.lklRecovery.Text = "EU NÃO LEMBRO DA SENHA PELO AMOR DE DEUS ME AJUDA PORFAVOR";
            this.lklRecovery.VisitedLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            // 
            // lblUsername
            // 
            this.lblUsername.AutoSize = true;
            this.lblUsername.BackColor = System.Drawing.SystemColors.Highlight;
            this.lblUsername.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUsername.Location = new System.Drawing.Point(7, 66);
            this.lblUsername.Name = "lblUsername";
            this.lblUsername.Size = new System.Drawing.Size(158, 26);
            this.lblUsername.TabIndex = 1;
            this.lblUsername.Text = "Nome de usuário";
            // 
            // lblPass
            // 
            this.lblPass.AutoSize = true;
            this.lblPass.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.lblPass.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPass.Location = new System.Drawing.Point(7, 133);
            this.lblPass.Name = "lblPass";
            this.lblPass.Size = new System.Drawing.Size(93, 26);
            this.lblPass.TabIndex = 3;
            this.lblPass.Text = "Password";
            // 
            // txbPass
            // 
            this.txbPass.Location = new System.Drawing.Point(12, 162);
            this.txbPass.Name = "txbPass";
            this.txbPass.PasswordChar = '•';
            this.txbPass.Size = new System.Drawing.Size(730, 20);
            this.txbPass.TabIndex = 4;
            // 
            // lklRegister
            // 
            this.lklRegister.ActiveLinkColor = System.Drawing.Color.Blue;
            this.lklRegister.AutoSize = true;
            this.lklRegister.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lklRegister.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.lklRegister.LinkColor = System.Drawing.Color.DeepSkyBlue;
            this.lklRegister.Location = new System.Drawing.Point(307, 370);
            this.lklRegister.Name = "lklRegister";
            this.lklRegister.Size = new System.Drawing.Size(145, 15);
            this.lklRegister.TabIndex = 6;
            this.lklRegister.TabStop = true;
            this.lklRegister.Text = "Não tenho um cadastro :(";
            this.lklRegister.UseMnemonic = false;
            this.lklRegister.UseWaitCursor = true;
            this.lklRegister.VisitedLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.lklRegister.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lklRegister_LinkClicked);
            // 
            // Login
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(754, 419);
            this.Controls.Add(this.lklRegister);
            this.Controls.Add(this.txbPass);
            this.Controls.Add(this.lblPass);
            this.Controls.Add(this.lblUsername);
            this.Controls.Add(this.lklRecovery);
            this.Controls.Add(this.txbUsername);
            this.Controls.Add(this.btnLogar);
            this.Controls.Add(this.lblTitle);
            this.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.MaximumSize = new System.Drawing.Size(770, 458);
            this.MinimumSize = new System.Drawing.Size(770, 458);
            this.Name = "Login";
            this.Text = "Entrar no sistema";
            this.Load += new System.EventHandler(this.Login_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Button btnLogar;
        private System.Windows.Forms.TextBox txbUsername;
        private System.Windows.Forms.LinkLabel lklRecovery;
        private System.Windows.Forms.Label lblUsername;
        private System.Windows.Forms.Label lblPass;
        private System.Windows.Forms.TextBox txbPass;
        private System.Windows.Forms.LinkLabel lklRegister;
    }
}

