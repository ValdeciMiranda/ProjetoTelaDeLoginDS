﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//using DAL_ProjetoDS;
//using DTOL_ProjetoDS;

namespace BLL_ProjetoDS
{
    public class Class1
    {
    }
}
