﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//using DTOL_ProjetoDS;

namespace DAL_ProjetoDS
{
    public class Class1
    {
    }
}
